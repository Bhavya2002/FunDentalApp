//
//  FunDentalApp.swift
//  FunDentalApp
//
//  Created by Bhavya Bhatia on 20/02/2025.
//

// App Logo designed using ChatGPT

import SwiftUI

@main
struct FunDentalApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
